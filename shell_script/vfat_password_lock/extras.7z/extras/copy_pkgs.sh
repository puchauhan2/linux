for i in `cat servers.txt`; do scp -i awslinuxstaging.pem -pr migration_pkgs gecloud@$i:/tmp; done
