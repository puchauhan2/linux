#!/bin/bash

os_check()
{
Default_IFS=$IFS
IFS="|"
CurrentOS=$(cat /etc/os-release |grep PRETTY_NAME |awk -F\" '{ print $2 }' |awk -F\( '{ print $1 }' |sed -e 's/ *$//' | awk -F. 'BEGIN{OFS="."} {print $1,$2}' |sed -e 's/\.$//')
SupportedOS=("CentOS Linux 7${IFS}Red Hat Enterprise Linux Server 7${IFS}Red Hat Enterprise Linux 8${IFS}Oracle Linux Server 7${IFS}Oracle Linux Server 8${IFS}Ubuntu 16.04${IFS}Ubuntu 18.04${IFS}Ubuntu 20.04${IFS}Ubuntu 22.04")
[[ $(grep -i "ID_LIKE.*fedora" /etc/os-release) ]] && CurrentOS=$(echo "$CurrentOS" |awk -F. '{print $1}')
if [[ ! "${IFS}${SupportedOS[*]}${IFS}" =~ "${IFS}${CurrentOS}${IFS}" ]]; then
  IPAddress=$(ip route get 1 |sed -nr 's/^.* src ([0-9.]+)( .*|)$/\1/p')
  echo "$IPAddress,OS is unsupported" && exit 1
fi
IFS=$Default_IFS
}

pkgs_check()
{
  IPAddress=$(ip route get 1 |sed -nr 's/^.* src ([0-9.]+)( .*|)$/\1/p')
  echo "$IPAddress"
  pkgs=("$@")
  pkgs_missing=()
  pkgs_exist=()
  if [[ "$1" == "fedora" ]]; then
    cmd='rpm -qa --qf "%{NAME}\n"'
  elif [[ "$1" == "debian" ]]; then
    cmd='dpkg-query -f "${Package}\n" -W'
  fi
  for pkg in "${pkgs[@]:2}"
  do
    if [[ ! "$($cmd |grep -w $pkg)" ]]; then
      pkgs_missing+=("$pkg")
    else
      pkgs_exist+=("$pkg")
    fi
  done
  [[ -z "${pkgs_missing[@]}" ]] && echo "No action required! All packages are already installed." && exit 0
  [[ -n "${pkgs_exist[@]}" ]] && echo "Packages already available in the server: "${pkgs_exist[@]}""
  echo "Packages that are missing: "${pkgs_missing[@]}""

  if [[ "${pkgs_missing[*]}" =~ "brutils" ]]; then
    pkgs_install "$1" "$2" "brutils"
    for pkg in "${pkgs_missing[@]}"
    do
      [[ $pkg != "brutils" ]] && tmp_pkg_missing+=($pkg)
    done
    pkgs_missing=("${tmp_pkg_missing[@]}")
    unset tmp_pkg_missing
    [[ -z "${pkgs_missing[@]}" ]] && echo "No action required!" && exit 0
    [[ -n "${pkgs_missing[@]}" ]] && pkgs_install "$1" "${pkgs_missing[@]}"
  else
    pkgs_install "$1" "${pkgs_missing[@]}"
  fi
}

pkgs_install()
{
  [[ "$1" == "fedora" ]] && pkg_mgr="yum"
  [[ "$1" == "debian" ]] && pkg_mgr="apt"
  if [[ "$3" == "brutils" ]]; then
    version=$(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}')
    [[ "$1" == "fedora" ]] && pckg_name="brutils-2.7-1.el8.x86_64.rpm"
    [[ ( "$1" == "debian" ) && ( "$version" == 16 ) || ( "$version" == 18 ) ]] && pckg_name="brutils_2.5-0-18_amd64.deb"
    [[ ( "$1" == "debian" ) && ( "$version" == 22 ) || ( "$version" == 20 ) ]] && pckg_name="brutils_2.5-0_amd64.deb"
    echo "Packages to be installed: brutils"
    [[ ! -f "$2"/"$pckg_name" ]] && echo "Please provide valid path. Installation package is missing!" && exit 1
    echo -e "\n\n###############$pkg_mgr install output starts###############\n\n"
    "$pkg_mgr" install -y "$2"/"$pckg_name"
    rc_install=$?
    echo -e "\n\n###############$pkg_mgr install output ends###############\n\n"
    if [[ $rc_install == 0 ]]; then
      echo "Following packages were installed successfully: brutils"
    else
      echo "brutils package installation failed!"
    fi
    return
  else
    echo "Packages to be installed: "${@:2}""
    echo -e "\n\n###############$pkg_mgr install output starts###############\n\n"
    "$pkg_mgr" install -y "${@:2}"
    rc_install=$?
    echo -e "\n\n###############$pkg_mgr install output ends###############\n\n"
    if [[ $rc_install == 0 ]]; then
     echo "Following packages were installed successfully: "${@:2}""
    else
     echo "Package installation failed!"
    fi
  fi
}

if [[ "$#" != 1 ]]; then
  echo "Please provide valid number of arguments! Please use help to know the syntax."
  exit 1
elif [[ ( "$1" == "help" ) || "$1" == "-h" ]]; then
  echo "Usage: bash $0 [PATH]"
  echo -e "\n   PATH\tThis needs the absolute PATH of the directory where brutils is located in the server."
  exit 0
elif ! os_check; then
  exit 1
elif [[ ! -d "$1" ]]; then
  echo "ERROR! Please provide valid directory path where brutils package is located on the server. Please use $0 help to know the syntax."
  exit 1
fi

if [[ $(grep -i "ID_LIKE.*fedora" /etc/os-release) ]]; then
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 7 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "dhclient" "gdisk" "nfs-utils" "iproute" "tar" "brutils")
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 8 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "dhcp-client" "gdisk" "grub2-pc" "nfs-utils" "iproute" "tar" "brutils")

  pkgs_check fedora "$1" "${arr_pkgs[@]}"

elif [[ $(grep -i "ID_LIKE.*debian" /etc/os-release) ]]; then
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 16 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "isc-dhcp-client" "gdisk" "nfs-common" "lsb-release" "iproute" "brutils")
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 18 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "isc-dhcp-client" "gdisk" "nfs-common" "lsb-release" "iproute2" "brutils")
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 20 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "isc-dhcp-client" "gdisk" "nfs-common" "e2fsprogs" "iproute2" "lsb-release" "brutils")
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 22 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "isc-dhcp-client" "gdisk" "nfs-common" "e2fsprogs" "iproute2" "lsb-release" "brutils")

  pkgs_check debian "$1" "${arr_pkgs[@]}"

fi