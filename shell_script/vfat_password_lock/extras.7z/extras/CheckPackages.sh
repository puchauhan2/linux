#!/bin/bash

os_check()
{
Default_IFS=$IFS
IFS="|"
CurrentOS=$(cat /etc/os-release |grep PRETTY_NAME |awk -F\" '{ print $2 }' |awk -F\( '{ print $1 }' |sed -e 's/ *$//' | awk -F. 'BEGIN{OFS="."} {print $1,$2}' |sed -e 's/\.$//')
SupportedOS=("CentOS Linux 7${IFS}Red Hat Enterprise Linux Server 7${IFS}Red Hat Enterprise Linux 8${IFS}Oracle Linux Server 7${IFS}Oracle Linux Server 8${IFS}Ubuntu 16.04${IFS}Ubuntu 18.04${IFS}Ubuntu 20.04${IFS}Ubuntu 22.04")
[[ $(grep -i "ID_LIKE.*fedora" /etc/os-release) ]] && CurrentOS=$(echo "$CurrentOS" |awk -F. '{print $1}')
if [[ ! "${IFS}${SupportedOS[*]}${IFS}" =~ "${IFS}${CurrentOS}${IFS}" ]]; then
  IPAddress=$(ip route get 1 |sed -nr 's/^.* src ([0-9.]+)( .*|)$/\1/p')
  echo "$IPAddress,OS is unsupported" && exit 1
fi
IFS=$Default_IFS
}

pkgs_check()
{
  IPAddress=$(ip route get 1 |sed -nr 's/^.* src ([0-9.]+)( .*|)$/\1/p')
  pkgs=("$@")
  pkgs_missing=()
  pkgs_exist=()
  printf -v pkgs_list '%s,' "${pkgs[@]:1}"
  echo "IPAddress,${pkgs_list%,}"
  if [[ "$1" == "fedora" ]]; then
    cmd='rpm -qa --qf "%{NAME}\n"'
  elif [[ "$1" == "debian" ]]; then
    cmd='dpkg-query -f "${Package}\n" -W'
  fi
  for pkg in "${pkgs[@]:1}"
  do
    if [[ ! "$($cmd |grep -w $pkg)" ]]; then
      pkgs_status+=("NotAvailable")
    else
      pkgs_status+=("Available")
    fi
  done
  printf -v pkgs_status_list '%s,' "${pkgs_status[@]}"
  echo "$IPAddress,${pkgs_status_list%,}"
}

os_check
if [[ $(grep -i "ID_LIKE.*fedora" /etc/os-release) ]]; then
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 7 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "dhclient" "gdisk" "nfs-utils" "iproute" "tar" "brutils")
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 8 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "dhcp-client" "gdisk" "grub2-pc" "nfs-utils" "iproute" "tar" "brutils")

  pkgs_check fedora "${arr_pkgs[@]}"

elif [[ $(grep -i "ID_LIKE.*debian" /etc/os-release) ]]; then
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 16 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "isc-dhcp-client" "gdisk" "nfs-common" "lsb-release" "iproute" "brutils")
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 18 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "isc-dhcp-client" "gdisk" "nfs-common" "lsb-release" "iproute2" "brutils")
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 20 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "isc-dhcp-client" "gdisk" "nfs-common" "e2fsprogs" "iproute2" "lsb-release" "brutils")
  [[ $(grep -i "VERSION_ID" /etc/os-release |awk -F'[^0-9]+' '{print $2}') -eq 22 ]] && declare -a arr_pkgs=("cifs-utils" "dmidecode" "dosfstools" "isc-dhcp-client" "gdisk" "nfs-common" "e2fsprogs" "iproute2" "lsb-release" "brutils")

  pkgs_check debian "${arr_pkgs[@]}"

fi