
# Store all currently set NETFS* variables into /etc/brutils/rescue.conf in the BRUTILS recovery system.
echo "# All set NETFS_* variables (cf. rescue/NETFS/default/600_store_NETFS_variables.sh):" >> $ROOTFS_DIR/etc/brutils/rescue.conf
set | grep '^NETFS_' >>$ROOTFS_DIR/etc/brutils/rescue.conf
echo "" >> $ROOTFS_DIR/etc/brutils/rescue.conf
