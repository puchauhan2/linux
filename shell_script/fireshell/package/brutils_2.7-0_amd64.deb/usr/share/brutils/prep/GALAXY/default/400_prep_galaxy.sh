#
# prepare stuff for Galaxy
#

COPY_AS_IS+=( "${COPY_AS_IS_GALAXY[@]}" )
COPY_AS_IS_EXCLUDE+=( "${COPY_AS_IS_EXCLUDE_GALAXY[@]}" )
