
# For "brutils mkbackup/mkrescue/mkbackuponly/mkopalpba"
# (i.e. for all workflows that run the 'prep' stage)
# check that the OUTPUT method is actually implemented
# i.e. check that a usr/share/brutils/output/$OUTPUT directory exists
# and error out when an OUTPUT method seems to be not supported
# to ensure that the user cannot specify a non-working OUTPUT in /etc/brutils/local.conf
# see https://github.com/brutils/brutils/issues/2501
# and cf. usr/share/brutils/prep/default/035_valid_backup_methods.sh

if ! test -d "$SHARE_DIR/output/$OUTPUT" ; then
    Error "The OUTPUT method '$OUTPUT' is not supported (no $SHARE_DIR/output/$OUTPUT directory)"
fi
