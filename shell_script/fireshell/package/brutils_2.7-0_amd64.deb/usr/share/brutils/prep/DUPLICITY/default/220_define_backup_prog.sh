# This file is part of brutils-backup-recovery-utility, licensed under the GNU General
# Public License. Refer to the included COPYING for full text of license.

echo "BACKUP_PROG=$BACKUP_PROG" >> "$ROOTFS_DIR/etc/brutils/rescue.conf"
LogIfError "Could not add BACKUP_PROG variable to rescue.conf"

Log "Defined BACKUP_PROG=$BACKUP_PROG"
