# we can write stuff to $CONFIG_DIR/rescue.conf if we want to preserve some dynamic variables
# so that they stay static in the rescue system. static means they stay the same as when the
# rescue system was created.

cat - <<EOF >> "$ROOTFS_DIR/etc/brutils/rescue.conf"
# initialize our /etc/brutils/rescue.conf file sourced by the brutils command in recover mode
# also the configuration is sourced by system-setup script during booting our recovery image

SHARE_DIR="/usr/share/brutils"
CONFIG_DIR="/etc/brutils"
VAR_DIR="/var/lib/brutils"
LOG_DIR="/var/log/brutils"

EOF
