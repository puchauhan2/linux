# mountonly-workflow.sh
#
# "mount only" workflow for brutils-backup-recovery-utility
#
# This file is part of brutils-backup-recovery-utility, licensed under the GNU General
# Public License. Refer to the included COPYING for full text of license.

WORKFLOW_mountonly_DESCRIPTION="use BRUTILS as live media to mount and repair the system"
WORKFLOWS+=( mountonly )
function WORKFLOW_mountonly () {
    # Adapt /etc/motd in the BRUTILS recovery system when 'brutils mountonly' is running
    # to avoid the additional 'Run "brutils recover" to restore your system !' message
    # that only makes sense as long as 'brutils mountonly' was not ever started,
    # see https://github.com/brutils/brutils/issues/1433
    # but do not (over)-write /etc/motd on the original system
    # which could happen in simulation mode via 'brutils -s mountonly'
    # that simulates sourcing scripts in the Source function
    # but this WORKFLOW_recover function call is not simulated (cf. usr/sbin/brutils)
    # see https://github.com/brutils/brutils/issues/1670
    # and do not (over)-write /etc/motd in the recovery system in simulation mode
    # which results with the above to never (over)-write /etc/motd in simulation mode:
    if ! is_true "$SIMULATE" ; then
        # In the recovery system /etc/brutils-release is unique (it does not exist otherwise)
        # cf. init/default/050_check_brutils_recover_mode.sh
        test -f /etc/brutils-release -a -w /etc/motd && echo -e '\nWelcome to brutils-backup-recovery-utility.\n' >/etc/motd
    fi

    SourceStage "setup"

    # 'check' stage is a minimal version of 'verify' that ignores all the
    # backup engines
    SourceStage "check"

    SourceStage "layout/prep-for-mount"
    SourceStage "layout/do-mount"

    SourceStage "final-mount"
    SourceStage "wrapup"
}
